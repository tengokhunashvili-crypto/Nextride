import { LucideIcon } from 'lucide-react';

interface Service {
  icon: LucideIcon;
  title: string;
  description: string;
}

interface ServiceCardProps {
  service: Service;
}

export function ServiceCard({ service }: ServiceCardProps) {
  const Icon = service.icon;
  
  return (
    <div className="bg-white rounded-[10px] p-6 border border-gray-200 hover:border-[#5e79ff] transition-all duration-300">
      <div className="mb-4">
        <Icon className="w-10 h-10 text-[#7084F2]" />
      </div>
      <h3 className="text-[20px] font-semibold text-[#1a202c] mb-3">{service.title}</h3>
      <p className="text-[14px] text-[#90a3bf]">{service.description}</p>
    </div>
  );
}