import { MessageCircle, Phone, Send, Instagram } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function ContactSection() {
  const { t } = useLanguage();
  const phoneNumber = '+995555123456'; // Placeholder number
  const instagramHandle = 'nextridegeorgia';

  return (
    <section id="contact" className="py-16 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-[16px] text-black mb-2">{t('getInTouch')}</p>
          <h2 className="text-[39px] text-black mb-4">{t('support247')}</h2>
          <p className="text-[#90a3bf]">
            {t('supportDesc')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* WhatsApp */}
          <a
            href={`https://wa.me/${phoneNumber.replace(/\D/g, '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-4 p-6 bg-white rounded-[10px] border border-gray-200 hover:border-green-500 hover:bg-green-50 transition-all duration-300 group"
          >
            <MessageCircle className="w-8 h-8 text-[#7084F2] group-hover:text-green-600" />
            <div className="text-left">
              <p className="text-[#90a3bf] text-[14px]">{t('whatsapp')}</p>
              <p className="text-[#1a202c] font-medium">{phoneNumber}</p>
            </div>
          </a>

          {/* Viber */}
          <a
            href={`viber://chat?number=${phoneNumber.replace(/\D/g, '')}`}
            className="flex items-center gap-4 p-6 bg-white rounded-[10px] border border-gray-200 hover:border-purple-500 hover:bg-purple-50 transition-all duration-300 group"
          >
            <Phone className="w-8 h-8 text-[#7084F2] group-hover:text-purple-600" />
            <div className="text-left">
              <p className="text-[#90a3bf] text-[14px]">{t('viber')}</p>
              <p className="text-[#1a202c] font-medium">{phoneNumber}</p>
            </div>
          </a>

          {/* Telegram */}
          <a
            href={`https://t.me/${phoneNumber.replace(/\D/g, '')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-4 p-6 bg-white rounded-[10px] border border-gray-200 hover:border-blue-500 hover:bg-blue-50 transition-all duration-300 group"
          >
            <Send className="w-8 h-8 text-[#7084F2] group-hover:text-blue-600" />
            <div className="text-left">
              <p className="text-[#90a3bf] text-[14px]">{t('telegram')}</p>
              <p className="text-[#1a202c] font-medium">{phoneNumber}</p>
            </div>
          </a>

          {/* Instagram */}
          <a
            href={`https://instagram.com/${instagramHandle}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-4 p-6 bg-white rounded-[10px] border border-gray-200 hover:border-pink-500 hover:bg-pink-50 transition-all duration-300 group"
          >
            <Instagram className="w-8 h-8 text-[#7084F2] group-hover:text-pink-600" />
            <div className="text-left">
              <p className="text-[#90a3bf] text-[14px]">{t('instagram')}</p>
              <p className="text-[#1a202c] font-medium">@{instagramHandle}</p>
            </div>
          </a>
        </div>
      </div>
    </section>
  );
}