import { CarCard } from './car-card';
import { useLanguage } from '../contexts/LanguageContext';

const cars = [
  {
    id: 1,
    name: 'Toyota RAV4',
    brand: 'Toyota',
    image: 'https://images.unsplash.com/photo-1617600346256-af3cd5b16a4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUb3lvdGElMjBSQVY0JTIwU1VWfGVufDF8fHx8MTc2NTU1ODcwMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 75,
    type: 'SUV',
  },
  {
    id: 2,
    name: 'Premium Sedan',
    brand: 'Luxury',
    image: 'https://images.unsplash.com/photo-1598889933677-e433366327f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWRhbiUyMGNhciUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NjU1NTg3MDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 65,
    type: 'Sedan',
  },
  {
    id: 3,
    name: 'Luxury SUV',
    brand: 'Premium',
    image: 'https://images.unsplash.com/photo-1758217209786-95458c5d30a7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBTVVYlMjB3aGl0ZXxlbnwxfHx8fDE3NjU1NTg3MDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 95,
    type: 'SUV',
  },
  {
    id: 4,
    name: '4x4 Off-Road',
    brand: 'Adventure',
    image: 'https://images.unsplash.com/photo-1593060136291-b63e6290449e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHw0eDQlMjBvZmZyb2FkJTIwdmVoaWNsZXxlbnwxfHx8fDE3NjU1NTg3MDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 110,
    type: '4x4',
  },
  {
    id: 5,
    name: 'Economy Sedan',
    brand: 'Compact',
    image: 'https://images.unsplash.com/photo-1598889933677-e433366327f6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWRhbiUyMGNhciUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3NjU1NTg3MDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 45,
    type: 'Sedan',
  },
  {
    id: 6,
    name: 'Family SUV',
    brand: 'Spacious',
    image: 'https://images.unsplash.com/photo-1617600346256-af3cd5b16a4d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxUb3lvdGElMjBSQVY0JTIwU1VWfGVufDF8fHx8MTc2NTU1ODcwMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    price: 85,
    type: 'SUV',
  },
];

export function CarListSection() {
  const { t } = useLanguage();
  
  return (
    <section id="fleet" className="py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <p className="text-[16px] text-black mb-2">{t('vehicleOptions')}</p>
          <h2 className="text-[39px] text-black">{t('browseByCarTypes')}</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {cars.map((car) => (
            <CarCard key={car.id} car={car} />
          ))}
        </div>
      </div>
    </section>
  );
}