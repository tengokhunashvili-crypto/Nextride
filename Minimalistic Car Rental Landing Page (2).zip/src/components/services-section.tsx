import { MapPin, Plane, Baby, Snowflake, Box, Smartphone } from 'lucide-react';
import { ServiceCard } from './service-card';
import { useLanguage } from '../contexts/LanguageContext';

export function ServicesSection() {
  const { t } = useLanguage();
  
  const services = [
    {
      icon: MapPin,
      title: t('flexibleDropOff'),
      description: t('flexibleDropOffDesc'),
    },
    {
      icon: Plane,
      title: t('airportTransfer'),
      description: t('airportTransferDesc'),
    },
    {
      icon: Baby,
      title: t('carSeat'),
      description: t('carSeatDesc'),
    },
    {
      icon: Snowflake,
      title: t('snowChains'),
      description: t('snowChainsDesc'),
    },
    {
      icon: Box,
      title: t('roofBox'),
      description: t('roofBoxDesc'),
    },
    {
      icon: Smartphone,
      title: t('simCard'),
      description: t('simCardDesc'),
    },
  ];

  return (
    <section id="services" className="py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-12">
          <p className="text-[16px] text-black mb-2">{t('additionalServices')}</p>
          <h2 className="text-[39px] text-black">{t('enhanceYourJourney')}</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((service, index) => (
            <ServiceCard key={index} service={service} />
          ))}
        </div>
      </div>
    </section>
  );
}