import { useLanguage } from '../contexts/LanguageContext';

export function Footer() {
  const { t } = useLanguage();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#1a202c] text-white py-16 px-6 mt-16">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="relative mb-4">
              <p className="font-bold text-[21.778px] text-white">{t('brandName')}</p>
              <div className="bg-[#5067e9] h-[5.444px] w-[calc(100%-20px)] mt-1" />
            </div>
            <p className="text-[#90a3bf] text-[14px]">
              {t('footerDescription')}
            </p>
          </div>

          {/* Quick Links & Car Types */}
          <div>
            <h4 className="text-white text-[16px] font-semibold mb-4">{t('quickLinks')}</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-[#90a3bf] text-[14px] hover:text-white transition-colors">
                  {t('home')}
                </a>
              </li>
              <li>
                <a href="#fleet" className="text-[#90a3bf] text-[14px] hover:text-white transition-colors">
                  {t('fleet')}
                </a>
              </li>
              <li>
                <a href="#services" className="text-[#90a3bf] text-[14px] hover:text-white transition-colors">
                  {t('services')}
                </a>
              </li>
              <li>
                <a href="#contact" className="text-[#90a3bf] text-[14px] hover:text-white transition-colors">
                  {t('contact')}
                </a>
              </li>
            </ul>
            <h4 className="text-white text-[16px] font-semibold mt-6 mb-4">{t('carTypes')}</h4>
            <ul className="space-y-2">
              <li>
                <a href="#fleet" className="text-[#90a3bf] text-[14px] hover:text-white transition-colors">
                  {t('suvRental')}
                </a>
              </li>
              <li>
                <a href="#fleet" className="text-[#90a3bf] text-[14px] hover:text-white transition-colors">
                  {t('sedanRental')}
                </a>
              </li>
              <li>
                <a href="#fleet" className="text-[#90a3bf] text-[14px] hover:text-white transition-colors">
                  {t('rental4x4')}
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-white text-[16px] font-semibold mb-4">{t('legal')}</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-[#90a3bf] text-[14px] hover:text-white transition-colors">
                  {t('terms')}
                </a>
              </li>
              <li>
                <a href="#" className="text-[#90a3bf] text-[14px] hover:text-white transition-colors">
                  {t('privacy')}
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-8 border-t border-gray-700 text-center">
          <p className="text-[#90a3bf] text-[14px]">
            © {currentYear} {t('copyright')}
          </p>
        </div>
      </div>
    </footer>
  );
}