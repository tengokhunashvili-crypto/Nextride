import { ChevronDown, Languages } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function HeroSection() {
  const { language, setLanguage, t } = useLanguage();
  
  const scrollToFleet = () => {
    document.getElementById('fleet')?.scrollIntoView({ behavior: 'smooth' });
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ru' : 'en');
  };

  return (
    <div className="relative">
      {/* Header */}
      <header className="relative z-20 bg-white mx-6 mt-5 rounded-[10px] border border-gray-200">
        <div className="max-w-7xl mx-auto px-5 py-5 flex items-center justify-between">
          <div className="relative">
            <p className="font-bold text-[21.778px] text-black">{t('brandName')}</p>
            <div className="bg-[#5067e9] h-[5.444px] w-[calc(100%-20px)] mt-1" />
          </div>
          
          <nav className="hidden md:flex items-center gap-8">
            <a href="#fleet" className="text-[14px] text-black hover:text-[#5067e9] transition-colors">
              {t('carFleet')}
            </a>
            <a href="#contact" className="text-[14px] text-black hover:text-[#5067e9] transition-colors">
              {t('aboutUs')}
            </a>
            <a href="#services" className="text-[14px] text-black hover:text-[#5067e9] transition-colors">
              {t('services')}
            </a>
            <a href="#contact" className="text-[14px] text-black hover:text-[#5067e9] transition-colors">
              {t('contact')}
            </a>
          </nav>

          <div className="flex items-center gap-3">
            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-2 px-3 py-2 rounded-md border border-gray-200 hover:border-[#5067e9] transition-colors"
              aria-label="Switch language"
            >
              <Languages className="w-4 h-4 text-[#5067e9]" />
              <span className="text-[14px] font-medium text-black uppercase">{language}</span>
            </button>

            <button className="bg-[#5067e9] text-white px-6 py-2.5 rounded-md hover:bg-[#4056d8] transition-colors">
              {t('bookACar')}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Content */}
      <div className="px-6 pt-20 pb-12">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-[61px] font-bold text-black leading-normal mb-4">
            {t('heroTitle')}
          </h1>
          <p className="text-[20px] text-[#434343] font-extralight max-w-4xl mx-auto leading-normal whitespace-pre-line">
            {t('heroDescription')}
          </p>
        </div>

        {/* Hero Image Section */}
        <div className="max-w-7xl mx-auto mt-32">
          <div className="relative h-[298px] rounded-[38px] overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1593865409468-2fa73ca58cf7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxHZW9yZ2lhJTIwbGFuZHNjYXBlJTIwbW91bnRhaW5zfGVufDF8fHx8MTc2NTU1ODcwNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Georgian landscape"
              className="absolute inset-0 w-full h-full object-cover"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <img
                src="https://images.unsplash.com/photo-1760465066570-6c2261f851e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBTVVYlMjBjYXIlMjBtb3VudGFpbnN8ZW58MXx8fHwxNzY1NTU4NzAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Luxury car"
                className="h-[416px] object-contain"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}