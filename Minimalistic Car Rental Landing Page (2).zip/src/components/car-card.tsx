import svgPaths from "../imports/svg-719kekgiyw";
import { useLanguage } from '../contexts/LanguageContext';

interface Car {
  id: number;
  name: string;
  brand: string;
  image: string;
  price: number;
  type: string;
}

interface CarCardProps {
  car: Car;
}

export function CarCard({ car }: CarCardProps) {
  const { t } = useLanguage();
  
  return (
    <div className="bg-white rounded-[10px] overflow-hidden flex flex-col h-[452px]">
      {/* Car Image - Full Width */}
      <div className="h-[200px] w-full overflow-hidden">
        <img
          src={car.image}
          alt={`${car.brand} ${car.name}`}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content Section */}
      <div className="p-4 flex flex-col gap-2.5 flex-1">
        {/* Car Name & Class */}
        <div className="flex flex-col">
          <h3 className="text-[25px] font-semibold text-[#1a202c]">{car.name}</h3>
          <p className="text-[13px] font-bold text-[#90a3bf]">{car.type}</p>
        </div>

        {/* Price */}
        <div className="flex items-end gap-2.5">
          <span className="text-[20px] font-bold text-[#1a202c]">${car.price}.00/</span>
          <span className="text-[13px] text-[#1a202c] pb-0.5">{t('perDay')}</span>
        </div>

        {/* Specifications */}
        <div className="flex items-start justify-between">
          {/* Fuel Type */}
          <div className="flex gap-2 items-start">
            <div className="w-6 h-6 shrink-0">
              <svg className="block size-full" fill="none" viewBox="0 0 24 24">
                <g>
                  <path d={svgPaths.p6bd5300} fill="#7084F2" opacity="0.5" />
                  <path d={svgPaths.p21b83000} fill="#7084F2" />
                </g>
              </svg>
            </div>
            <span className="text-[14px] font-medium text-[#90a3bf] tracking-[-0.28px] leading-[1.5]">{t('hybrid')}</span>
          </div>

          {/* Transmission */}
          <div className="flex gap-2 items-start">
            <div className="w-6 h-6 shrink-0">
              <svg className="block size-full" fill="none" viewBox="0 0 24 24">
                <g>
                  <path d={svgPaths.p8f64a00} fill="#7084F2" opacity="0.5" />
                  <path d={svgPaths.p17ed2c00} fill="#7084F2" />
                </g>
              </svg>
            </div>
            <span className="text-[14px] font-medium text-[#90a3bf] tracking-[-0.28px] leading-[1.5]">{t('automatic')}</span>
          </div>

          {/* Capacity */}
          <div className="flex gap-1.5 items-start">
            <div className="w-6 h-6 shrink-0">
              <svg className="block size-full" fill="none" viewBox="0 0 24 24">
                <g>
                  <path clipRule="evenodd" d={svgPaths.pe33d380} fill="#7084F2" fillRule="evenodd" />
                  <path d={svgPaths.p16fab00} fill="#7084F2" opacity="0.5" />
                </g>
              </svg>
            </div>
            <span className="text-[14px] font-medium text-[#90a3bf] tracking-[-0.28px] leading-[1.5]">{t('economy')}</span>
          </div>
        </div>

        {/* Rent Button */}
        <button className="bg-[#5e79ff] text-white rounded-[44px] h-[44px] px-5 hover:bg-[#4d68ee] transition-colors mt-auto">
          <span className="text-[20px] font-medium">{t('rentNow')}</span>
        </button>
      </div>
    </div>
  );
}