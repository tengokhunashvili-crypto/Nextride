export type Language = 'en' | 'ru';

export const translations = {
  en: {
    // Header
    brandName: 'NextRideGeorgia',
    carFleet: 'Car Fleet',
    aboutUs: 'About us',
    services: 'Services',
    contact: 'Contact',
    bookACar: 'Book A Car',
    
    // Hero
    heroTitle: 'Rent Your Ride, Anytime, Anywhere!',
    heroDescription: 'Discover the ease of car rentals designed to fit your lifestyle. Whether you\'re planning a quick city\ndrive, a weekend getaway, or a long-term journey.',
    
    // Car List
    vehicleOptions: 'Vehicles Options',
    browseByCarTypes: 'Browse by car types',
    perDay: 'day',
    rentNow: 'Rent Now',
    
    // Car Specs
    hybrid: 'Hybrid',
    automatic: 'Automatic',
    economy: 'Economy',
    
    // Car Types
    suv: 'SUV',
    sedan: 'Sedan',
    luxury: 'Luxury',
    adventure: '4x4',
    compact: 'Compact',
    spacious: 'Spacious',
    
    // Services
    additionalServices: 'Additional Services',
    enhanceYourJourney: 'Enhance Your Journey',
    
    // Service Items
    flexibleDropOff: 'Flexible Location Drop-Off',
    flexibleDropOffDesc: 'Drop the car at any location that suits you best',
    airportTransfer: 'Airport Transfer',
    airportTransferDesc: 'Meet at airport or drop-off service available separately',
    carSeat: 'Car Seat / Child Safety',
    carSeatDesc: 'Child safety seats available for your peace of mind',
    snowChains: 'Snow Chains',
    snowChainsDesc: 'Essential wheel chains for safe mountain driving',
    roofBox: 'Roof Top Baggage Box',
    roofBoxDesc: 'Additional baggage space for all your gear',
    simCard: 'Local SIM Card Assistance',
    simCardDesc: 'Stay connected throughout your journey',
    
    // Contact
    getInTouch: 'Get In Touch',
    support247: '24/7 Support',
    supportDesc: 'We\'re always here to help. Reach out through your preferred channel.',
    whatsapp: 'WhatsApp',
    viber: 'Viber',
    telegram: 'Telegram',
    instagram: 'Instagram',
    
    // Footer
    footerDescription: 'Premium car rental service for exploring the beautiful landscapes of Georgia.',
    quickLinks: 'Quick Links',
    home: 'Home',
    fleet: 'Fleet',
    carTypes: 'Car Types',
    suvRental: 'SUV Rental',
    sedanRental: 'Sedan Rental',
    rental4x4: '4x4 Rental',
    legal: 'Legal',
    terms: 'Terms & Conditions',
    privacy: 'Privacy Policy',
    copyright: 'NextRideGeorgia. All rights reserved.',
  },
  ru: {
    // Header
    brandName: 'NextRideGeorgia',
    carFleet: 'Автопарк',
    aboutUs: 'О нас',
    services: 'Услуги',
    contact: 'Контакты',
    bookACar: 'Забронировать',
    
    // Hero
    heroTitle: 'Арендуйте авто в любое время и в любом месте!',
    heroDescription: 'Откройте для себя удобство аренды автомобилей, разработанной для вашего образа жизни. Планируете ли вы быструю поездку по городу, выходные или длительное путешествие.',
    
    // Car List
    vehicleOptions: 'Варианты автомобилей',
    browseByCarTypes: 'Выберите по типу автомобиля',
    perDay: 'день',
    rentNow: 'Арендовать',
    
    // Car Specs
    hybrid: 'Гибрид',
    automatic: 'Автомат',
    economy: 'Эконом',
    
    // Car Types
    suv: 'Внедорожник',
    sedan: 'Седан',
    luxury: 'Люкс',
    adventure: '4x4',
    compact: 'Компакт',
    spacious: 'Семейный',
    
    // Services
    additionalServices: 'Дополнительные услуги',
    enhanceYourJourney: 'Улучшите ваше путешествие',
    
    // Service Items
    flexibleDropOff: 'Гибкое место возврата',
    flexibleDropOffDesc: 'Верните автомобиль в любом удобном для вас месте',
    airportTransfer: 'Трансфер в аэропорт',
    airportTransferDesc: 'Встреча в аэропорту или услуга доставки доступна отдельно',
    carSeat: 'Детское автокресло',
    carSeatDesc: 'Детские автокресла для вашего спокойствия',
    snowChains: 'Цепи противоскольжения',
    snowChainsDesc: 'Необходимые цепи для безопасного вождения в горах',
    roofBox: 'Багажник на крышу',
    roofBoxDesc: 'Дополнительное место для багажа',
    simCard: 'Помощь с местной SIM-картой',
    simCardDesc: 'Оставайтесь на связи на протяжении всего путешествия',
    
    // Contact
    getInTouch: 'Связаться с нами',
    support247: 'Поддержка 24/7',
    supportDesc: 'Мы всегда готовы помочь. Свяжитесь с нами удобным способом.',
    whatsapp: 'WhatsApp',
    viber: 'Viber',
    telegram: 'Telegram',
    instagram: 'Instagram',
    
    // Footer
    footerDescription: 'Премиальная услуга аренды автомобилей для изучения красивых ландшафтов Грузии.',
    quickLinks: 'Быстрые ссылки',
    home: 'Главная',
    fleet: 'Автопарк',
    carTypes: 'Типы автомобилей',
    suvRental: 'Аренда внедорожника',
    sedanRental: 'Аренда седана',
    rental4x4: 'Аренда 4x4',
    legal: 'Юридическая информация',
    terms: 'Условия использования',
    privacy: 'Политика конфиденциальности',
    copyright: 'NextRideGeorgia. Все права защищены.',
  },
};

export function getTranslation(lang: Language, key: keyof typeof translations.en): string {
  return translations[lang][key];
}
