# NextRideGeorgia - Car Rental Landing Page

A modern, minimalistic car rental landing page built with React, TypeScript, and Tailwind CSS.

## Features

- 🌍 Bilingual support (English/Russian)
- 🚗 Car fleet showcase with 6 vehicle options
- 🛠️ Additional services section
- 📱 Instant contact via WhatsApp, Viber, Telegram, Instagram
- 📱 Fully responsive design
- ⚡ Fast and optimized

## Deployment to Netlify

### Quick Deploy

1. **Install dependencies:**

   ```bash
   npm install
   ```

2. **Build the project:**

   ```bash
   npm run build
   ```

3. **Deploy:**
   - Option A: Drag and drop the `dist` folder to [Netlify Drop](https://app.netlify.com/drop)
   - Option B: Connect your Git repository to Netlify (auto-deploys on push)

### Troubleshooting

If you encounter build errors:

- Make sure Node.js version 18 or higher is installed
- Delete `node_modules` folder and `package-lock.json`, then run `npm install` again
- Check that all dependencies installed correctly

## Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Tech Stack

- React 18
- TypeScript
- Vite
- Tailwind CSS 4
- Lucide React (icons)

## SEO Optimized

- Meta descriptions
- Semantic HTML
- Fast loading times
- Mobile-friendly

---

© 2024 NextRideGeorgia. All rights reserved.