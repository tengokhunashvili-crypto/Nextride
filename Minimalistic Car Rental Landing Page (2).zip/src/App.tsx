import { HeroSection } from './components/hero-section';
import { CarListSection } from './components/car-list-section';
import { ServicesSection } from './components/services-section';
import { ContactSection } from './components/contact-section';
import { Footer } from './components/footer';
import { LanguageProvider } from './contexts/LanguageContext';

export default function App() {
  return (
    <LanguageProvider>
      <div className="min-h-screen bg-[#f4f4f4]">
        <HeroSection />
        <CarListSection />
        <ServicesSection />
        <ContactSection />
        <Footer />
      </div>
    </LanguageProvider>
  );
}