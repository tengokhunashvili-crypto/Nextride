
  # Minimalistic Car Rental Landing Page

  This is a code bundle for Minimalistic Car Rental Landing Page. The original project is available at https://www.figma.com/design/HvNfY12SmigZRF0oXzQ37Z/Minimalistic-Car-Rental-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  