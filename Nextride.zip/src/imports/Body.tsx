import svgPaths from "./svg-719kekgiyw";
import imgBackImageCar from "figma:asset/dd6d564089ddc8494f372b046cfe1d78142a0cb7.png";
import imgCarItselfv1 from "figma:asset/8342b84e4026e7e21323e2616f74f84b32da2c93.png";
import imgCarImage from "figma:asset/509322661844e6b8d2bc7a68f501d79e35f5f4ab.png";

function Wrapper1({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 size-[24px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        {children}
      </svg>
    </div>
  );
}

function Wrapper({ children }: React.PropsWithChildren<{}>) {
  return (
    <Wrapper1>
      <g id="solar:bolt-bold-duotone">{children}</g>
    </Wrapper1>
  );
}
type ButtonRentalTextProps = {
  text: string;
};

function ButtonRentalText({ text }: ButtonRentalTextProps) {
  return (
    <div className="bg-[#5e79ff] h-[44px] relative rounded-[44px] shrink-0 w-full">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-stretch flex items-center justify-center px-[20px] py-0 relative size-full">
          <div className="flex flex-col font-['Geist:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[20px] text-center text-nowrap text-white">
            <p className="leading-[normal] whitespace-pre">{text}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
type CapacityTextProps = {
  text: string;
};

function CapacityText({ text }: CapacityTextProps) {
  return (
    <div className="content-stretch flex gap-[7px] items-start relative shrink-0">
      <Wrapper>
        <path clipRule="evenodd" d={svgPaths.pe33d380} fill="var(--fill-0, #7084F2)" fillRule="evenodd" id="Vector" />
        <path d={svgPaths.p16fab00} fill="var(--fill-0, #7084F2)" id="Vector_2" opacity="0.5" />
      </Wrapper>
      <div className="flex flex-col font-['Plus_Jakarta_Sans:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] relative shrink-0 text-[#90a3bf] text-[14px] tracking-[-0.28px] w-[60px]">
        <p className="leading-[1.5]">{text}</p>
      </div>
    </div>
  );
}
type CarTextProps = {
  text: string;
};

function CarText({ text }: CarTextProps) {
  return (
    <div className="content-stretch flex gap-[8px] items-start relative shrink-0 w-[103px]">
      <Wrapper1>
        <g id="solar:transmission-square-bold-duotone">
          <path d={svgPaths.p8f64a00} fill="var(--fill-0, #7084F2)" id="Vector" opacity="0.5" />
          <path d={svgPaths.p17ed2c00} fill="var(--fill-0, #7084F2)" id="Vector_2" />
        </g>
      </Wrapper1>
      <div className="flex flex-col font-['Plus_Jakarta_Sans:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#90a3bf] text-[14px] text-nowrap tracking-[-0.28px]">
        <p className="leading-[1.5] whitespace-pre">{text}</p>
      </div>
    </div>
  );
}
type GasolineTextProps = {
  text: string;
};

function GasolineText({ text }: GasolineTextProps) {
  return (
    <div className="content-stretch flex gap-[8px] items-start relative shrink-0">
      <Wrapper1>
        <g id="solar:fuel-bold-duotone">
          <path d={svgPaths.p6bd5300} fill="var(--fill-0, #7084F2)" id="Vector" opacity="0.5" />
          <path d={svgPaths.p21b83000} fill="var(--fill-0, #7084F2)" id="Vector_2" />
        </g>
      </Wrapper1>
      <div className="flex flex-col font-['Plus_Jakarta_Sans:Medium',sans-serif] font-medium justify-center leading-[0] relative shrink-0 text-[#90a3bf] text-[14px] text-nowrap tracking-[-0.28px]">
        <p className="leading-[1.5] whitespace-pre">{text}</p>
      </div>
    </div>
  );
}
type HelperProps = {
  text: string;
  text1: string;
};

function Helper({ text, text1 }: HelperProps) {
  return (
    <div className="content-stretch flex gap-[10px] items-end leading-[0] relative shrink-0 text-[#1a202c] text-nowrap w-full">
      <div className="flex flex-col font-['Geist:Bold',sans-serif] font-bold justify-center relative shrink-0 text-[20px]">
        <p className="leading-[normal] text-nowrap whitespace-pre">{text}</p>
      </div>
      <div className="flex flex-col font-['Geist:Regular',sans-serif] font-normal justify-center relative shrink-0 text-[13px]">
        <p className="leading-[normal] text-nowrap whitespace-pre">{text1}</p>
      </div>
    </div>
  );
}

function Image() {
  return (
    <div className="h-[164px] relative shrink-0 w-[370px]">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <img alt="" className="absolute h-[178.57%] left-0 max-w-none top-[-40.18%] w-full" src={imgCarImage} />
      </div>
    </div>
  );
}
type CarNameProps = {
  text: string;
  text1: string;
};

function CarName({ text, text1 }: CarNameProps) {
  return (
    <div className="content-stretch flex flex-col items-start leading-[0] relative shrink-0 w-full">
      <div className="flex flex-col font-['Geist:SemiBold',sans-serif] font-semibold justify-center relative shrink-0 text-[#1a202c] text-[25px] text-nowrap">
        <p className="leading-[normal] whitespace-pre">{text}</p>
      </div>
      <div className="flex flex-col font-['Geist:Bold',sans-serif] font-bold h-[20px] justify-center relative shrink-0 text-[#90a3bf] text-[13px] w-[128px]">
        <p className="leading-[normal]">{text1}</p>
      </div>
    </div>
  );
}
type TextProps = {
  text: string;
};

function Text({ text }: TextProps) {
  return (
    <div className="absolute bottom-0 content-stretch flex flex-col items-start left-[10px] px-[10px] py-0 top-[-1px]">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] not-italic relative shrink-0 text-[14px] text-black text-nowrap whitespace-pre">{text}</p>
    </div>
  );
}

export default function Body() {
  return (
    <div className="bg-[#f4f4f4] relative size-full" data-name="Body">
      <div className="absolute bg-white content-stretch flex h-[75px] items-start justify-between left-[33px] p-[20px] right-[29px] rounded-[10px] top-[21px]" data-name="Section → Banner">
        <div aria-hidden="true" className="absolute border-[0px_0px_1px] border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[10px]" />
        <div className="absolute content-stretch flex flex-col items-start left-[450.86px] top-[27.69px]" data-name="Container">
          <div className="content-stretch flex items-end relative shrink-0 w-full" data-name="Navigation">
            <div className="h-[16.79px] relative shrink-0 w-[99.86px]" data-name="Link:margin">
              <Text text="Car Fleet" />
            </div>
            <div className="h-[16.79px] relative shrink-0 w-[99.09px]" data-name="Link:margin">
              <Text text="About us" />
            </div>
            <div className="h-[16.79px] relative shrink-0 w-[97.46px]" data-name="Link:margin">
              <Text text="Services" />
            </div>
            <div className="h-[16.79px] relative shrink-0 w-[76.92px]" data-name="Link:margin">
              <Text text="Blogs" />
            </div>
            <div className="flex flex-row items-end self-stretch">
              <div className="content-stretch flex flex-col h-full items-start justify-center max-w-[1356px] px-[10px] py-0 relative shrink-0" data-name="Margin">
                <div className="content-stretch flex flex-col h-[17.79px] items-center max-w-[1336px] px-[10px] py-0 relative shrink-0" data-name="Container">
                  <div className="content-stretch flex gap-[8px] items-end relative shrink-0 w-[62.95px]" data-name="Button menu">
                    <div className="flex flex-row items-end self-stretch">
                      <div className="content-stretch flex flex-col h-full items-start relative shrink-0" data-name="Container">
                        <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16.8px] not-italic relative shrink-0 text-[14px] text-black text-nowrap whitespace-pre">Pages</p>
                      </div>
                    </div>
                    <div className="content-stretch flex flex-col h-[16.79px] items-start max-w-[62.95000076293945px] overflow-clip relative shrink-0" data-name="Arrow">
                      <div className="content-stretch flex flex-col h-[16.79px] items-center justify-center overflow-clip pb-[0.89px] pt-[0.9px] px-0 relative shrink-0 w-[14px]" data-name="67503bd2fa4a4255091349f1_dropdown-arrow.svg fill">
                        <div className="h-[15px] relative shrink-0 w-[14px]" data-name="Component 1">
                          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 15">
                            <g id="Component 1">
                              <path d={svgPaths.p25bec0c0} id="Vector" stroke="var(--stroke-0, black)" strokeLinecap="round" strokeLinejoin="round" />
                            </g>
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="h-[29.944px] relative shrink-0 w-[98px]" data-name="LOGO">
          <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[normal] left-0 not-italic text-[21.778px] text-black text-nowrap top-0 whitespace-pre">RENTALL</p>
          <div className="absolute bg-[#5067e9] h-[5.444px] left-[1.36px] top-[23.14px] w-[74.861px]" />
          <p className="absolute font-['Inter:Bold',sans-serif] font-bold leading-[normal] left-[78.95px] not-italic text-[6.806px] text-black text-nowrap top-[21.78px] whitespace-pre">CLUB</p>
        </div>
        <div className="bg-[#5067e9] content-stretch flex items-center overflow-clip px-[24px] py-[10px] relative rounded-[6px] shrink-0" data-name="Component 3">
          <div className="flex flex-col font-['Geist:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[16px] text-center text-nowrap text-white">
            <p className="leading-[normal] whitespace-pre">Book A Car</p>
          </div>
        </div>
      </div>
      <div className="absolute content-stretch flex flex-col gap-[188px] items-center left-[33px] top-[181px] w-[1378px]">
        <div className="content-stretch flex flex-col gap-[16px] items-center relative shrink-0 w-full">
          <div className="content-stretch flex flex-col items-center relative shrink-0 w-[1081.22px]" data-name="Heading 1">
            <p className="font-['Geist:Bold',sans-serif] font-bold leading-[normal] relative shrink-0 text-[61px] text-black text-center text-nowrap whitespace-pre">Rent Your Ride, Anytime, Anywhere!</p>
          </div>
          <div className="font-['Geist:ExtraLight',sans-serif] font-extralight leading-[normal] min-w-full relative shrink-0 text-[#434343] text-[20px] text-center w-[min-content]">
            <p className="mb-0">{`Discover the ease of car rentals designed to fit your lifestyle. Whether you're planning a quick city`}</p>
            <p>drive, a weekend getaway, or a long-term journey.</p>
          </div>
        </div>
        <div className="content-stretch flex flex-col items-center relative shrink-0 w-full" data-name="Search">
          <div className="h-[298px] relative rounded-[38px] shrink-0 w-full" data-name="Back image & car">
            <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-[38px]">
              <img alt="" className="absolute h-[335.72%] left-[-13.93%] max-w-none top-[-203.86%] w-[127.58%]" src={imgBackImageCar} />
            </div>
            <div className="absolute h-[416px] left-[233px] top-[-118px] w-[869px]" data-name="Car itselfv 1">
              <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCarItselfv1} />
            </div>
          </div>
        </div>
      </div>
      <div className="absolute content-stretch flex flex-col gap-[24px] items-start left-[34px] top-[990px] w-[1372px]" data-name="Catalog">
        <div className="content-stretch flex flex-col font-['Geist:Regular',sans-serif] font-normal items-start leading-[normal] relative shrink-0 text-black text-nowrap w-[1363px] whitespace-pre" data-name="H2">
          <p className="relative shrink-0 text-[16px]">Vehicles Options</p>
          <p className="relative shrink-0 text-[39px]">Browse by car types</p>
        </div>
        <div className="content-start flex flex-wrap gap-[27px_20px] h-[1410px] items-start relative shrink-0 w-full" data-name="Catalogue lsit">
          <div className="bg-white content-stretch flex flex-col gap-[10px] h-[452px] items-start overflow-clip px-[9px] py-[16px] relative rounded-[10px] shrink-0 w-[444px]" data-name="Card">
            <CarName text="Toyota, Camry" text1="Economy" />
            <div className="basis-0 content-stretch flex flex-col grow items-center justify-center min-h-px min-w-px overflow-clip px-0 py-[25px] relative rounded-[7px] shrink-0 w-full" data-name="Thumbnail holder">
              <Image />
            </div>
            <Helper text="$99.00/" text1="day" />
            <div className="content-stretch flex items-start justify-between relative shrink-0 w-full" data-name="Info Icons">
              <GasolineText text="Hybryd" />
              <CarText text="Automatic" />
              <CapacityText text="Econom" />
            </div>
            <ButtonRentalText text="Rent Now" />
          </div>
          {[...Array(5).keys()].map((_, i) => (
            <div className="bg-white content-stretch flex flex-col gap-[10px] h-[452px] items-start overflow-clip px-[9px] py-[16px] relative rounded-[10px] shrink-0 w-[444px]" data-name="Card">
              <CarName text="Toyota, Camry" text1="Economy" />
              <div className="basis-0 content-stretch flex flex-col grow items-center justify-center min-h-px min-w-px overflow-clip px-0 py-[25px] relative rounded-[7px] shrink-0 w-full">
                <Image />
              </div>
              <Helper text="$99.00/" text1="day" />
              <div className="content-stretch flex items-start justify-between relative shrink-0 w-full" data-name="Spesification">
                <GasolineText text="Hybryd" />
                <CarText text="Automatic" />
                <CapacityText text="Econom" />
              </div>
              <ButtonRentalText text="Rent Now" />
            </div>
          ))}
          {[...Array(3).keys()].map((_, i) => (
            <div className="bg-white content-stretch flex flex-col gap-[10px] h-[452px] items-start overflow-clip px-[9px] py-[16px] relative rounded-[10px] shrink-0 w-[444px]" data-name="Card">
              <CarName text="Toyota, Camry" text1="Economy" />
              <div className="basis-0 content-stretch flex flex-col grow items-center justify-center min-h-px min-w-px overflow-clip px-0 py-[25px] relative rounded-[7px] shrink-0 w-full">
                <Image />
              </div>
              <Helper text="$99.00/" text1="day" />
              <div className="content-stretch flex items-start justify-between relative shrink-0 w-full" data-name="Spesification">
                <GasolineText text="Hybryd" />
                <CarText text="Automatic" />
                <div className="content-stretch flex gap-[7px] items-start relative shrink-0" data-name="Capacity">
                  <Wrapper>
                    <path clipRule="evenodd" d={svgPaths.pd51cca0} fill="var(--fill-0, #7084F2)" fillRule="evenodd" id="Vector" />
                    <path d={svgPaths.p16fab00} fill="var(--fill-0, #7084F2)" id="Vector_2" opacity="0.5" />
                  </Wrapper>
                  <div className="flex flex-col font-['Plus_Jakarta_Sans:Medium',sans-serif] font-medium h-[24px] justify-center leading-[0] relative shrink-0 text-[#90a3bf] text-[14px] tracking-[-0.28px] w-[60px]">
                    <p className="leading-[1.5]">Econom</p>
                  </div>
                </div>
              </div>
              <ButtonRentalText text="Rent Now" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}